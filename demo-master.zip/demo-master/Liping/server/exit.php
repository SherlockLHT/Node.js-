<?php
/**
 * Created by PhpStorm.
 * User: zws
 * Date: 2016/5/24
 * Time: 20:34
 */

session_start();

$_SESSION['username']=null;

