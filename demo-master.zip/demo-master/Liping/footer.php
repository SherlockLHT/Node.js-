<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/css1.css">
</head>
<body>
    <div class="footer">
        <div class="foot-main">
            <span><a href="#">关于我们</a></span>
            <span><a href="#">深大首页</a></span>
            <span><a href="#">使用帮助</a></span>
            <span><a href="#">联系我们</a></span>


            <span>加入我们、链接更多深大好课&nbsp;&nbsp;&nbsp;<img src="img/erweima.jpg"  width="100px" height="100px" alt=""></span>

            <div class="hr"></div>
            <div class="cpy">Copyright &copy; webnoob</div>
        </div>

    </div>
</body>
</html>