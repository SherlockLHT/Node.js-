网页版的2048，适配移动端。

在线演示：[http://www.wozien.com/2048](http://www.wozien.com/2048)

![my 2048](2048.jpg 'my 2048')

代码说明：[document](http://blog.csdn.net/Szu_AKer/article/details/52685941)